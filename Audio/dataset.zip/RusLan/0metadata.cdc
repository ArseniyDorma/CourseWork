@UTF8
Title:	CHILDES Russian RusLan Corpus
Creator:	Sekerina, Irina
Language:	rus
Description:	two children learning Russian
Date:		2025
Country:	Russia

DOI:	10.21415/1XMG-D508
